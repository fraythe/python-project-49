#!/usr/bin/env python3


from brain_games.games.gcd import nod

def main():
    nod()

if __name__ == '__main__':
    main()
