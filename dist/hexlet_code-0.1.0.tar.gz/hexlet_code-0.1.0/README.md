### Hexlet tests and linter status:
[![Actions Status](https://github.com/fraythe/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/fraythe/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/86240b798d040bf7c455/maintainability)](https://codeclimate.com/github/fraythe/python-project-49/maintainability)
